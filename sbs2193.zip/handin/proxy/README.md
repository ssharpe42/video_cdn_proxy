Files:

- socket_utils.py - helper functions
- proxy - implements and runs proxy server